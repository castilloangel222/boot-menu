Updated rEFInd Script from jlobue10's v1.0.7 release

All Credit goes to jlobue10 as always for creating this incredible script for dual booting!

Make sure to read all of Jlobue10's documentation included on recent changes!

jlobue10 Steam Deck rEFInd Script altered with a few tweaks

    Replaced background.png

    Increased Timeout to 15 from 5 on OS Selection

Original Creator of Script - https://github.com/jlobue10/SteamDeck_rEFInd

YouTube Tutorial - https://www.youtube.com/watch?v=uYWNZGiBsUo

Deck Wizard YouTube Channel - https://www.youtube.com/c/DeckWizard

Deck Wizard Discord for Help/Troubleshooting - https://discord.com/invite/YrFj5vW4Jb

Thank you all!